//Function to update Display
function updateDisplay(value) {
    let display = document.getElementById("display");
    display.value += value;
}

// Function to calculate The Expression
function calculate() {
    let display = document.getElementById("display");

    try {
        display.value = eval(display.value); //Evaluating the expression
    } catch (error) {
        display.value = "Error";
    }
}

// Function to clear Display
function clearDisplay() {
    let display = document.getElementById("display");
    display.value = "";

}
//  Function to delete element
function deletelast() {
    let display = document.getElementById("display");
    display.value = display.value.slice(0, -1);
}

// Disabling Right Click
document.addEventListener('contextmenu',function(event) {
    event.preventDefault();
    alert("Right Click Disabled")
});